## castrated CDC test (single interface with 3 endpoints)

As mentioned [here](https://arduino.stackexchange.com/a/31695/62145), Arduino functions can be _overwritten_ by copying complete files into the own project. 

This is used to create a castrated CDC device with a single interface containing 3 endpoints. 

The modifications have been done against Arduino 1.8.10, for changes see comments containing `kai`.

